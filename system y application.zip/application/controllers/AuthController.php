<?php
defined('BASEPATH') OR exit('No direct script access allowed');
require APPPATH . '/libraries/REST_Controller.php';
require APPPATH . '/libraries/Format.php';

class AuthController extends REST_Controller {
    public function __construct()
    {
        header('Access-Control-Allow-Origin: *');
        header("Access-Control-Allow-Headers: X-API-KEY, Origin, X-Requested-With, Content-Type, Accept, Access-Control-Request-Method");
        header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");
        header("Allow: GET, POST, OPTIONS, PUT, DELETE");
        $method = $_SERVER['REQUEST_METHOD'];
        if($method == "OPTIONS") {
            die();
        }

        parent::__construct();

        if (!isset($_POST)) {
            echo $this->response('Ha ocurrido un error inesperado, porfavor intentalo de nuevo.');
        }

        if ($_SERVER['REQUEST_METHOD'] == 'POST' && empty($_POST))
            $_POST = json_decode(file_get_contents('php://input'), true);

        $this->load->model('User_model');
    }

    public function singUp_post () 
    {
        $p = $this->input->post();

        if ( !isset($p['enrollment']) || !isset($p['firstName']) || !isset($p['lastName']) || !isset($p['email']) || !isset($p['password']) || !isset($p['career'])) {
            echo $this->response([
                'status' => false,
                'message' => 'Porfavor completa todos los campos!'
            ]); die;
        }

        $CheckEnrollment = $this->User_model->CheckEnrollment ($p['enrollment']);

        if ($CheckEnrollment) { // LA MATRICULA YA ESTA REGISTRADA
            echo $this->response([
                'status' => false,
                'message' => 'Error. Esta matricula ya esta registrada!'
            ]); die;
        }

        $passwordHash = md5($p['password']);

        $data = [
            'enrollment' => $p['enrollment'],
            'firstName' => $p['firstName'],
            'lastName' => $p['lastName'],
            'email' => $p['email'],
            'password' => $passwordHash,
            'career' => $p['career'],
        ];

        $response = $this->User_model->SaveUser($data);

        if ($response) {
            echo $this->response([
                'status' => true,
                'message' => 'Usuario registrado exitosamente!'
            ]);
        } else {
            echo $this->response([
                'status' => false,
                'message' => 'Ha ocurrido un error guardando el usuario, comuniquese con un administrador!'
            ]);
        }
    }

    public function logIn_post ()
    {
        $p = $this->input->post();

        if ( !isset($p['enrollment']) || empty($p['enrollment']) || !isset($p['password']) || empty($p['password'])) {
            echo $this->response([
                'status' => false,
                'message' => 'Porfavor completa todos los campos!'
            ]); die;
        }

        $response = $this->User_model->LogIn ([
            'enrollment' => $p['enrollment'],
            'password' => md5($p['password'])
        ]);
        
        if (!$response) { // SI EL USUARIO NO EXISTE....
            echo $this->response([
                'status' => false,
                'message' => 'Usuario o contraseña incorrectos!'
            ]); die;
        }

        echo $this->response([
            'status' => true,
            'message' => 'Inicio de session realizado',
            'user' => $response
        ]);
    }

    public function get_career_post () {
        $careers = $this->db->select('*')->from('career')->get()->result_array();

        $this->response([
            'status' => true,
            'careers' => $careers
        ]);
    }
}
