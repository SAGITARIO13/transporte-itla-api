<?php
defined('BASEPATH') OR exit('No direct script access allowed');
require APPPATH . '/libraries/REST_Controller.php';
require APPPATH . '/libraries/Format.php';

class RoutesController extends REST_Controller {

    public function __construct()
    {
        header('Access-Control-Allow-Origin: *');
        header("Access-Control-Allow-Headers: X-API-KEY, Origin, X-Requested-With, Content-Type, Accept, Access-Control-Request-Method");
        header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");
        header("Allow: GET, POST, OPTIONS, PUT, DELETE");
        $method = $_SERVER['REQUEST_METHOD'];
        if($method == "OPTIONS") {
            die();
        }

        parent::__construct();

        if (!isset($_POST)) {
            echo $this->response('Ha ocurrido un error inesperado, porfavor intentalo de nuevo.');
        }

        if ($_SERVER['REQUEST_METHOD'] == 'POST' && empty($_POST))
            $_POST = json_decode(file_get_contents('php://input'), true);

        $this->load->model('Routes_model');
    }

    public function validFields ($data, $keys) {
        foreach ($keys as $value) {
            if (!isset($data[$value]) || empty($data[$value])) {
                return false;
            }
        }
        
        return true;
    }

    public function get_routes_post ()
    {
        $routes = $this->Routes_model->GetRoutes();

        if (!$routes) {
            $this->response([
                'status' => false,
                'routes' => array(),
                'message' => 'Ha ocurrido un error obteniendo las routas. Porfavor contacte con un administrador!'
            ]); die;
        }

        $this->response([
            'status' => true,
            'routes' => $routes
        ]);
    }

    public function update_driver_location_get ()
    {
        echo $this->response('ACTUALIZANDO UBICACION DEL CONDUCTOR...');

        $this->db->insert('career', ['name' => 'test']);
    } 
}
