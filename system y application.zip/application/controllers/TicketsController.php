<?php
defined('BASEPATH') OR exit('No direct script access allowed');
require APPPATH . '/libraries/REST_Controller.php';
require APPPATH . '/libraries/Format.php';

class TicketsController extends REST_Controller {

    public function __construct()
    {
        header('Access-Control-Allow-Origin: *');
        header("Access-Control-Allow-Headers: X-API-KEY, Origin, X-Requested-With, Content-Type, Accept, Access-Control-Request-Method");
        header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");
        header("Allow: GET, POST, OPTIONS, PUT, DELETE");
        $method = $_SERVER['REQUEST_METHOD'];
        if($method == "OPTIONS") {
            die();
        }

        parent::__construct();

        if (!isset($_POST)) {
            echo $this->response('Ha ocurrido un error inesperado, porfavor intentalo de nuevo.');
        }

        if ($_SERVER['REQUEST_METHOD'] == 'POST' && empty($_POST))
            $_POST = json_decode(file_get_contents('php://input'), true);

        $this->load->model('Tickets_model');
    }

    public function validFields ($data, $keys) {
        foreach ($keys as $value) {
            if (!isset($data[$value]) || empty($data[$value])) {
                return false;
            }
        }
        
        return true;
    }

    public function save_request_post ()
    {
        $p = $this->input->post();
        
        $validFields = $this->validFields($p, ['user_id']);

        if (!$validFields) {
            $this->response([
                'status' => false,
                'message' => 'Porfavor completa todos los campos'
            ]); die;
        }

        // HERE I SAVE THE REQUEST TICKET
        $response = $this->Tickets_model->SaveTicket ($p);

        if ($response) {
            $this->response([
                'status' => true,
                'message' => 'Ticket reservado exitosamente!'
            ]);
        } else {
            $this->response([
                'status' => true,
                'message' => 'Hubo un error al procesar su solicitud!'
            ]);
        }
    }

    public function delete_ticket_post () 
    {
        $p = $this->input->post();
        
        $validFields = $this->validFields($p, ['ticketId']);

        if (!$validFields) {
            $this->response([
                'status' => false,
                'message' => 'Porfavor completa todos los campos'
            ]); die;
        }

        $response = $this->Tickets_model->DeleteTicket($p['ticketId']);

        if ($response) {
            $this->response([
                'status' => true,
                'message' => 'Ticket eliminado exitosamente!'
            ]);
        } else {
            $this->response([
                'status' => true,
                'message' => 'Hubo un error al procesar su solicitud!'
            ]);
        }
    }

    public function get_tickets_post () 
    {
        $p = $this->input->post();
        
        $validFields = $this->validFields($p, ['user_id']);

        if (!$validFields) {
            $this->response([
                'status' => false,
                'message' => 'Porfavor completa todos los campos'
            ]); die;
        }

        $tickets = $this->Tickets_model->GetTickets($p['user_id']);

        if ($tickets) {
            $this->response([
                'status' => true,
                'tickets' => $tickets
            ]);
        } else {
            $this->response([
                'status' => true,
                'tickets' => [],
                'message' => 'Hubo un error al procesar su solicitud!'
            ]);
        }
    }

    public function get_reserved_tickets_post () 
    {
        $p = $this->input->post();
        
        $validFields = $this->validFields($p, ['user_id']);

        if (!$validFields) {
            $this->response([
                'status' => false,
                'message' => 'Porfavor completa todos los campos'
            ]); die;
        }

        $tickets = $this->Tickets_model->GetTickets ($p['user_id'], true);
        
        if ($tickets) {
            $this->response([
                'status' => true,
                'tickets' => $tickets
            ]);
        } else {
            $this->response([
                'status' => true,
                'tickets' => [],
                'message' => 'Hubo un error al procesar su solicitud!'
            ]);
        }
    }

    public function pay_tickets_post () 
    {
        $p = $this->input->post();

        $validFields = $this->validFields($p, ['user_id', 'tickets']);

        if (!$validFields) {
            $this->response([
                'status' => false,
                'message' => 'Porfavor completa todos los campos!'
            ]); die;
        }

        $current_balance = $this->db->select('balance')->from('users')->where('ID', $p['user_id'])->get()->row()->balance;

        if ($current_balance === null || (int)$current_balance <= 0) {
            $this->response([
                'status' => false,
                'message' => 'No tienes saldo suficiente para pagar este ticket.'
            ]); die;
        }


        $response = $this->Tickets_model->PayTickets ($p['user_id'], $p['tickets']);

        if ($response) {
            $this->response([
                'status' => true,
                'message' => 'Ticket Reservado exitosamente!'
            ]); die;
        } else {
            $this->response([
                'status' => false,
                'message' => 'Hubo un error al procesar su solicitud'
            ]); die;
        }
    }

    public function get_ticket_report_post ()
    {
        $p = $this->input->post();
        
        $validFields = $this->validFields($p, ['user_id']);

        if (!$validFields) {
            $this->response([
                'status' => false,
                'message' => 'Hubo un error procesando su solicitud.'
            ]); die;
        }

        $date = false;

        if (isset($p['date']) && !empty($p['date'])) {
            if ($p['date'] === 'day') {
                $firstDate = date('Y-m-d'); 
                $lastDate = date('Y-m-d'); 
            } else if ($p['date'] === 'week') {
                $today = date('N'); 
                $firstDate = date('Y-m-d', strtotime("-".($today-1)." days")); 
                $lastDate = date('Y-m-d', strtotime("+6 days", strtotime($firstDate))); 
            } else if ($p['date'] === 'month') {
                $month = date('m');
                $firstDate = date('Y-m-01');
                $lastDate = date('Y-m-d', strtotime('-1 day', strtotime(date('Y-m-01').' +1 month')));
            }
        }   

        $tickets_report = $this->Tickets_model->TicketsReport($p['user_id'], $firstDate, $lastDate);
        $user_balance = $this->db->select('balance')->from('users')->where('ID', $p['user_id'])->get()->row()->balance;

        if ($tickets_report) {
            $this->response([
                'status' => true,
                'data' => $tickets_report,
                'balance' => $user_balance
            ]);
        } else {
            $this->response([
                'status' => true,
                'data' => [],
                'message' => 'Hubo un error al procesar su solicitud!'
            ]);
        }
    }
}
