<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Tickets_model extends CI_Model {

    public function __construct()
    {
        parent::__construct();
    }

    public function SaveTicket ($data) {
        $insertData = array();

        if (isset($data['arrivalRoute']) && !empty($data['arrivalRoute'])) { // SI SE SELECCIONA UN TICKET DE ENTRADA LO INSERTAMOS
            array_push($insertData, [
                'date' => $data['date'],
                'user_id' => $data['user_id'],
                'route_id' => $data['arrivalRoute'],
                'route_schedule_id' => $data['arrivalRouteSchedule'],
                'is_paid' => 0,
                'redeemed' => 0
            ]);
        }

        if (isset($data['exitRoute']) && !empty($data['exitRoute'])) { // SI SE SELECCIONA UN TICKET DE SALIDA LO INSERTAMOS
            array_push($insertData, [
                'date' => $data['date'],
                'user_id' => $data['user_id'],
                'route_id' => $data['exitRoute'],
                'route_schedule_id' => $data['exitRouteSchedule'],
                'is_paid' => 0,
                'redeemed' => 0
            ]);
        }

        return $this->db->insert_batch('reserved_tickets', $insertData);
    }

    public function DeleteTicket ($ticketId) {
        $response = $this->db->delete('reserved_tickets', ['ID' => $ticketId]);

        return $response ? true : false;
    }

    // OBTENER LISTA DE TICKET RESERVADOS
    public function GetTickets ($userId, $getReserved = false) { 
        // IS_PAID => 0 (TICKET SIN PAGAR, ES DECIR, TICKETS SOLICITADOS).
        // IS_PAID => 1 (TICKET PAGADOS, ES DECIR, TICKETS RESERVADOS).

        $ticketType = $getReserved ? 1 : 0;

        $this->db->select('ticket.ID, routes.name, ticket.date, DATE_ADD(ticket.date, INTERVAL -1 DAY) AS pay_before, ticket_schedule.time, ticket_schedule.is_exit')
             ->from('reserved_tickets ticket')
             ->join('routes', 'ticket.route_id = routes.ID')
             ->join('route_schedules ticket_schedule', 'ticket.route_schedule_id = ticket_schedule.ID')
             ->where(['ticket.user_id' => $userId, 'is_paid' => $ticketType])->order_by('ID', 'DESC');

        return $this->db->get()->result_array();
    }

    public function PayTickets ($userId, $tickets) {
        if (count($tickets) === 0) {
            return false;
        }

        try {
            foreach ($tickets as $ticket) {
                $this->db->update('reserved_tickets', ['is_paid' => 1], ['ID' => (int)$ticket, 'user_id' => $userId]);

                $current_balance = $this->db->select('balance')->from('users')->where('ID', $userId)->get()->row()->balance;
                $current_balance = (float)$current_balance;
                
                $new_balance = $current_balance - 25;

                $this->db->update('users', ['balance' => $new_balance], ['ID' => $userId]);
            }

            return true;
        } catch (Exception $error) {
            var_dump($error->getMessage());
            return false;
        }
    }

    public function TicketsReport ($userId, $firstDate, $lastDate)
    {
        $request_tickets = $this->db->select('ID')->from('reserved_tickets')->where(['is_paid' => 0, 'user_id' => $userId])->where(" DATE(date) BETWEEN '{$firstDate}' AND '{$lastDate}' ")->get()->num_rows();

        $reserverd_tickets = $this->db->select('ID')->from('reserved_tickets')->where(['is_paid' => 1, 'user_id' => $userId])->where(" DATE(date) BETWEEN '{$firstDate}' AND '{$lastDate}' ")->get()->num_rows();

        return [
            'request_tickets' => $request_tickets,
            'reserverd_tickets' => $reserverd_tickets
        ];
    }
}   
