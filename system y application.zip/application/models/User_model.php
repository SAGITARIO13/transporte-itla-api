<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User_model extends CI_Model {
    public $id;
    public $enrollment;
    public $firstname;
    public $lastName;
    public $email;
    public $password;
    public $career;

    public function __construct()
    {
        parent::__construct();
    }
    

    public function CheckEnrollment ( $enrollment ) { // SI LA MATRICULA YA EXISTE.
        $response = $this->db->select('ID')->from('users')->where('enrollment', $enrollment)->get()->num_rows();

        return $response > 0 ? true : false;
    }

    public function SaveUser ($data = []) // GUARDAR USUARIO EN LA BASE DE DATOS
    {
        if (!isset($data['id'])) { 
            // CREAR NUEVO
            $response = $this->db->insert('users', $data);
        } else {
            // EDITAR UNO EXISTENTE
            $response = $this->db->update('users', $data, [ 'ID' => $p['id'] ]);
        }
        
        return $response ? true : false;
    }

    public function LogIn ($data = [])
    {
        $this->enrollment = $data['enrollment'];
        $this->password = $data['password'];

        //VALIDAR SI EL USUARIO EXISTE
        $validUser =  $this->db->select('ID')->from('users')->where([ 'enrollment' => $this->enrollment, 'password' => $this->password ])->get()->num_rows();

        if ($validUser <= 0) { // SI NO EXISTE DEVOLVEMOS FALSE
            $response = false;
        }
        
        // SI EXISTE OBTENEMOS LOS DATOS DEL USUARIO
        $response = $this->db->select('*')->from('users')->where([ 'enrollment' => $this->enrollment, 'password' => $this->password ])->get()->row();
        return $response;
    }
}
