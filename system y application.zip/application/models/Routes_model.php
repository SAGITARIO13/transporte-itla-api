<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Routes_model extends CI_Model {

    public function __construct()
    {
        parent::__construct();
    }

    public function GetRoutes () {
        $this->db->select('routes.ID, routes.name, route_schedules.ID AS schedule_id, route_schedules.time, route_schedules.is_exit')->from('routes')
             ->join('route_schedules', 'routes.ID = route_schedules.route_id');

        return $this->db->get()->result_array();
    }
}   
